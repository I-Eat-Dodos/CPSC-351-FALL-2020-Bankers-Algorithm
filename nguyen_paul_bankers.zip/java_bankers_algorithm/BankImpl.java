//-------------------------------------------------------------------------------------------------
// BankImpl.java
//
// implementation of the Bank
//
import java.io.*;
import java.util.*;

public class BankImpl implements Bank {
    private int n;			// the number of threads in the system
    private int m;			// the number of resources

    private int[] available; 	// the amount available of each resource
    private int[][] maximum; 	// the maximum demand of each thread
    private int[][] allocation;	// the amount currently allocated to each thread
    private int[][] need;		// the remaining needs of each thread

    private void showAllMatrices(int[][] alloc, int[][] max, int[][] need, String msg) {
		// todo
	}

    private void showMatrix(int[][] matrix, String title, String rowTitle) {
      System.out.println(title);      // Print out title of matrix
      // Print out integers within matrix
      for (int i = 0; i < matrix.length(); i++){      // column
        System.out.println("[ ");
        for (int j = 0; k < matrix[i].length(); i++){     // row
          System.out.println(matrix[i][j] + ' ');
        }
        System.out.println(" ]");
      }
    }

    private void showVector(int[] vect, String msg) {
      System.out.println("[ " + vect[0] + ' ' + vect[1] + ' ' + vect[2] + " ]");
    }

    public BankImpl(int[] resources) {      // create a new bank (with resources)
      m = resources.size();
      for (int i = 0; i < m; i++){
        available[i] = resources[i];
      }
    }

    // invoked by a thread when it enters the system;  also records max demand
    public void addCustomer(int threadNum, int[] allocated, int[] maxDemand) {
		for (int i = 0; i < maxDemand.size(); i++){
      maximum[threadNum][i] = maxDemand[i];
    }
   }

    public void getState() {        // output state for each thread
		// todo
    }

    private boolean isSafeState (int threadNum, int[] request) {
		// todo -- actual banker's algorithm
    }

    // make request for resources. will block until request is satisfied safely
    public synchronized boolean requestResources(int threadNum, int[] request)  {
 		// todo
     }

    public synchronized void releaseResources(int threadNum, int[] release)  {
		// todo
}
